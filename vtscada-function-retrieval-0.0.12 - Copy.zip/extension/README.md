# README

## Build

```
python model2onnx.py
npm install
npx vsce package
vsce package
```