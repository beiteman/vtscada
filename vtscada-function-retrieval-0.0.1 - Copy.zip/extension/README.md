# README

## Build

```
npm install
python model2onnx.py
vsce package
```